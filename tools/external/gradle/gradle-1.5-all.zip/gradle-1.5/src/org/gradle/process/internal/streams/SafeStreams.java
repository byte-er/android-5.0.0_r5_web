/*
 * Copyright 2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.process.internal.streams;

import org.apache.commons.io.output.CloseShieldOutputStream;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * by Szczepan Faber, created at: 4/17/12
 */
public class SafeStreams {

    public static OutputStream systemErr() {
        return new CloseShieldOutputStream(System.err);
    }

    public static InputStream emptyInput() {
        return new ByteArrayInputStream(new byte[0]);
    }

    public static OutputStream systemOut() {
        return new CloseShieldOutputStream(System.out);
    }
}
